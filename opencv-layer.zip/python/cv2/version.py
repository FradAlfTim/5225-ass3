opencv_version = "4.10.0.82"
contrib = False
headless = True
rolling = False
ci_build = True